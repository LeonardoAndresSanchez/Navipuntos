<?php
require_once "controller/registroController.php";
require_once "model/registroModel.php";
header("Access-Control-Allow-Origin: *");


if(isset($_GET["ruta"]))
{
    
    if($_GET["ruta"]=="registro")
    {
        // var_dump($_POST); 
    
       
        if($_POST["validacion"]=="usuario")
        {
            $item="cedulaUsuario";
            $valor=$_POST["cedulaUsuario"];
            $validarRegistro= RegistroController::ctrConsulta($item, $valor);
            if(!$validarRegistro)
            {
                $respuesta= RegistroController::ctrRegistrarUsuario($_POST);
            
                if($respuesta=="ok")
                {
                    echo '[{"respuestaInsercion":"ok"}]';
                }
                else
                {
                    echo '[{"respuestaInsercion":"error"}]';
                }   
            }
            else
            {
                echo '[{"respuestaInsercion":"yaExiste"}]';
            }

            
        }
        else if($_POST["validacion"]=="factura")
        {
            // var_dump($_POST);

            $respuesta= RegistroController::ctrRegistrarFactura($_POST);
            
            if($respuesta=="ok")
            {
                echo '[{"respuestaInsercion":"ok"}]';
            }
            else
            {
                echo '[{"respuestaInsercion":"error"}]';
            }   
            
            
        }
        
    }

    else if($_GET["ruta"]=="consultaInfoUsuario")
    {
        $actual_link = "http://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
        $parts = parse_url($actual_link);
        parse_str($parts['query'], $query);
        // var_dump($query);
        $valor=$query["idUsuario"];
        $item="idUsuario";
        $respuesta= RegistroController::ctrConsulta($item, $valor);
        echo json_encode($respuesta);
    }
    else if($_GET["ruta"]=="validarQr")
    {
        $actual_link = "http://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
        $parts = parse_url($actual_link);
        parse_str($parts['query'], $query);
      

        $item="idUsuario";
        $valor=$query["qrCode"];
        $respuesta= RegistroController::ctrConsulta($item, $valor);
       
        if(!$respuesta)
        {
            echo '[{"respuestaQr":"noExiste"}]';
        }
        else
        {
            echo '[{"respuestaQr":"siExiste"}]';
        }
      
    }
    else if($_GET["ruta"]=="insertarseLaImagen")
    {
        $actual_link = "http://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
        $parts = parse_url($actual_link);
        parse_str($parts['query'], $query);
        var_dump($query["imagen"]);
    
    }
    else if($_GET["ruta"]=="consultaCatalogo")
    {
        $valor= null;
        $item=null;
        $respuesta= RegistroController::ctrConsultarCatalogo();
        $respuestaJson=json_encode($respuesta);
        $JsonSinSlash   = str_replace("\/", "/", $respuestaJson);
        echo $JsonSinSlash;
    }
    else if($_GET["ruta"]=="consultaActividadesDiarias")
    {
        $actual_link = "http://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
        $parts = parse_url($actual_link);
        parse_str($parts['query'], $query);
        $valor= $query["idUsuario"];
        $item="idUsuario";
        $respuesta= RegistroController::ctrConsultarActividadesHoy($item, $valor);
        // $respuestaJson=json_encode($respuesta);
        // $JsonSinSlash   = str_replace("\/", "/", $respuestaJson);
        echo json_encode($respuesta);
    }
    else if($_GET["ruta"]=="consultaActividades")
    {
        $actual_link = "http://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
        $parts = parse_url($actual_link);
        parse_str($parts['query'], $query);

        $respuesta=null;

        $valor= $query["idActividad"];
        $item="idActividad";
        $tabla="";

        switch ($query["idTipoActividad"]) {
            case '1':
                $tabla="palabraactividad";
                $respuesta= RegistroController::ctrConsultarActividad($tabla, $item, $valor);
                echo json_encode($respuesta);

                break;
            case '2':
                $tabla="imagenpuzzle";
                $respuesta= RegistroController::ctrConsultarActividad($tabla, $item, $valor);
                $respuestaJson=json_encode($respuesta);
                $JsonSinSlash   = str_replace("\/", "/", $respuestaJson);
                echo $JsonSinSlash;
                break;
            case '3':
                $tabla="imagenactividad";
                $respuesta= RegistroController::ctrConsultarActividad($tabla, $item, $valor);
                $respuestaJson=json_encode($respuesta);
                $JsonSinSlash   = str_replace("\/", "/", $respuestaJson);
                echo $JsonSinSlash;
                break;
            case '4':
                $tabla="preguntaseleccionmultiple";
                $respuesta= RegistroController::ctrConsultarActividad($tabla, $item, $valor);
                $respuestaJson=json_encode($respuesta);
                $JsonSinSlash   = str_replace("\/", "/", $respuestaJson);
                echo $JsonSinSlash;
                break;
            default:
                # code...
                break;
        }  
    }
    else if($_GET["ruta"]=="consultaRespuestas")
    {
        
        $respuesta= RegistroController::ctrConsultarRespuestas();
        echo json_encode($respuesta);
    }

    else if($_GET["ruta"]=="consultaLogin")
    {
       
        $actual_link = "http://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
        $parts = parse_url($actual_link);
        parse_str($parts['query'], $query);
        


        $contraseña=$query["passwordUsuario"];
        $usuario=$query["emailUsuario"];
        $respuesta= RegistroController::ctrConsultaLogin($usuario, $contraseña);
        // var_dump($respuesta);
        if(!$respuesta)
        {
            echo '[{"respuestaLogin":"errorLogin"}]';
        }
        else
        {
            $respuestaSesion=RegistroController::ctrActualizarSesion($usuario, $contraseña);
            // var_dump($respuestaSesion);
            if($respuestaSesion=="ok")
            {
                echo '[{"respuestaLogin":"acceso", "idUsuario":"'.$respuesta["idUsuario"].'"}]';
            }
            
        }
    }
    else if($_GET["ruta"]=="validarSesion")
    {

        $actual_link = "http://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
        $parts = parse_url($actual_link);
        parse_str($parts['query'], $query);

        $idUsuario=$query["idUsuario"];
        $respuesta= RegistroController::ctrValidarSesion($idUsuario);
        
        if($respuesta["estadoSesionUsuario"])
        {
            echo '[{"respuestaLogin":"sesionIniciada"}]';
        }
        else
        {
            echo '[{"respuestaLogin":"sesionCerrada"}]';
        }
        
    }
    else if($_GET["ruta"]=="validarActividadCompletada")
    {
        $actual_link = "http://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
        $parts = parse_url($actual_link);
        parse_str($parts['query'], $query);

        $tabla="actividadesfinalizadas";
        $item="idUsuarioActividad";
        $valor= $query["idUsuarioActividad"];
        $respuesta= RegistroController::ctrConsultarActividad($tabla, $item, $valor);
        if(!$respuesta)
        {
            echo '[{"respuestaValidacion":"noCompletada"}]';
        }
        else
        {
            echo '[{"respuestaValidacion":"completada"}]';

        }
        // echo json_encode($respuesta);
    }
    else if($_GET["ruta"]=="consultaActividadesDiariasFinalizadas")
    {
        $actual_link = "http://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
        $parts = parse_url($actual_link);
        parse_str($parts['query'], $query);
        $valor= $query["idUsuario"];
        $item="idUsuario";
        $respuesta= RegistroController::ctrConsultaActividadesDiariasFinalizadas($item, $valor);
        // $respuestaJson=json_encode($respuesta);
        // $JsonSinSlash   = str_replace("\/", "/", $respuestaJson);
        echo json_encode($respuesta);
    }
    else if($_GET["ruta"]=="registroActividadFinalizada")
    {

        $respuesta= RegistroController::ctrRegistrarActividadFinalizada($_POST);
        
        if($respuesta=="ok")
        {
            echo '[{"respuestaInsercion":"ok"}]';
        }
        else
        {
            echo '[{"respuestaInsercion":"error"}]';
        }   
    }
    else if($_GET["ruta"]=="validarPuntos")
    {
        $actual_link = "http://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
        $parts = parse_url($actual_link);
        parse_str($parts['query'], $query);

        
        $valor= $query["idUsuario"];
        $respuesta= RegistroController::ctrConsultarPuntos($valor);
        if(is_null($respuesta[0]["puntos"]))
        {
            echo '[{"puntos":"0","0":"0"}]';
        }

        else
        {
            echo json_encode($respuesta);
        }
        
    }
    else if($_GET["ruta"]=="insertarUsuarioPremio")
    {

        $respuesta= RegistroController::ctrInsertarUsuarioPremio($_POST);
        
        if($respuesta=="ok")
        {
            echo '[{"respuestaInsercion":"ok"}]';
        }
        else
        {
            echo '[{"respuestaInsercion":"error"}]';
        }   
    }

}