<?php
class RegistroController
{
    static public function ctrRegistrarUsuario($datos)
    {
        $respuesta=RegistroModelo::mdlRegistrarUsuario($datos);
        return $respuesta;
    }
    static public function ctrRegistrarFactura($arreglo)
    {
        //ar_dump($arreglo);
        $img = $arreglo['image']; // Your data 'data:image/png;base64,AAAFBfj42Pj4';
            $img = str_replace('data:image/png;base64,', '', $img);
            $img = str_replace(' ', '+', $img);
            $data = base64_decode($img);
            $directorio = "img/" . $arreglo["idUsuario"];

            if (!is_dir("img/" . $arreglo["idUsuario"])) {
                mkdir($directorio, 0755);

            }
            $numero=rand(0,9999);
            
            file_put_contents($directorio."/imagenFactura".$numero.".png", $data);

            $directorioFinal=$directorio."/imagenFactura".$numero.".png";
            $fechaFactura = date('Y-m-d h:i:s', strtotime(str_replace("/", "-", $arreglo["fechaFactura"])));
            $datos= array
            (
                
                "almacenFactura"=>$arreglo["almacenFactura"],
                "fechaFactura"=> $fechaFactura,
                "rutaImagen"=>$directorioFinal,
                "idUsuario"=>$arreglo["idUsuario"],
                
            );
            // var_dump($datos["idUsuario"]);
        $respuesta=RegistroModelo::mdlRegistrarFactura($datos);
        return $respuesta;
    }

    static public function ctrConsulta($item, $valor)
    {
        $respuesta=RegistroModelo::mdlConsulta($item, $valor);
        return $respuesta;
    }
    static public function ctrConsultaLogin($usuario, $contraseña)
    {
        $respuesta=RegistroModelo::mdlConsultaLogin($usuario, $contraseña);
        return $respuesta;
    }
    
    static public function ctrActualizarSesion($usuario, $contraseña)
    {
        $respuesta=RegistroModelo::mdlActualizarSesion($usuario, $contraseña);
        return $respuesta;
    }
    static public function ctrConsultarCatalogo()
    {
        $respuesta=RegistroModelo::mdlConsultarCatalogo();
        return $respuesta;
    }
    static public function ctrConsultarActividadesHoy($item, $valor)
    {
        $respuesta=RegistroModelo::mdlConsultarActividadesHoy($item, $valor);
        return $respuesta;
    }
    static public function ctrConsultaActividadesDiariasFinalizadas($item, $valor)
    {
        $respuesta=RegistroModelo::mdlConsultaActividadesDiariasFinalizadas($item, $valor);
        return $respuesta;
    }

    static public function ctrConsultarActividad($tabla, $item, $valor)
    {
        $respuesta=RegistroModelo::mdlConsultarActividad($tabla, $item, $valor);
        return $respuesta;
    }

    static public function ctrValidarSesion($idUsuario)
    {
        $respuesta=RegistroModelo::mdlValidarSesion($idUsuario);
        return $respuesta;
    }
    static public function ctrRegistrarActividadFinalizada($datos)
    {
        $respuesta=RegistroModelo::mdlRegistrarActividadFinalizada($datos);
        return $respuesta;
    }

    static public function ctrConsultarPuntos($valor)
    {
        $respuesta=RegistroModelo::mdlConsultarPuntos($valor);
        return $respuesta;
    }

    static public function ctrConsultarRespuestas()
    {
        $respuesta=RegistroModelo::mdlConsultarRespuestas();
        return $respuesta;
    }
    static public function ctrInsertarUsuarioPremio($datos)
    {
        $respuesta=RegistroModelo::mdlInsertarUsuarioPremio($datos);
        return $respuesta;
    }
    static public function ctrPuntosTotalesUsuario($datos)
    {
        $respuesta=RegistroModelo::mdlPuntosTotalesUsuario($datos);
        return $respuesta;
    }
    
}
