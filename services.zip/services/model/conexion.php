<?php

class Conexion
{

    public static function conectar()
    {
        //cambiar cuando este en el server por los datos de conexión a la BD del HOST
        // $link = new PDO('mysql:host=localhost;dbname=navipuntosv2', 'root', ''); 
        // $link->exec("set names utf8");

        //  return $link;

        $link = new PDO("mysql:host=51.79.99.155; dbname=luisfgra_sistemaCapacitaciones", "luisfgra_admin", "XNHeBGj!s^qO");
        $link->exec("set names utf8");
        return $link;


    }

}
