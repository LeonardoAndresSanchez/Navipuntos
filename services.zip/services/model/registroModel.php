<?php
require_once "conexion.php";
class RegistroModelo
{
    static public function mdlRegistrarUsuario($datos)
    {
        // update prueba set nombreUsuario=:nombreUsuario where idUsuario=:idUsuario
        // delete from prueba where $item=$valor
        // var_dump($datos);
        $stmt = Conexion::conectar()->prepare("INSERT INTO usuario (cedulaUsuario ,nombreUsuario ,telefonoUsuario ,emailUsuario ,passwordUsuario, estadoSesionUsuario) VALUES  (:identificacionCliente,:nombreCliente,:telefonoCliente ,:correoCliente,:passwordCliente, true)");

        $stmt->bindParam(":identificacionCliente", $datos["cedulaUsuario"], PDO::PARAM_STR);
        $stmt->bindParam(":nombreCliente", $datos["nombreUsuario"], PDO::PARAM_STR);
        $stmt->bindParam(":telefonoCliente", $datos["telefonoUsuario"], PDO::PARAM_STR);
        $stmt->bindParam(":correoCliente", $datos["emailUsuario"], PDO::PARAM_STR);
        $stmt->bindParam(":passwordCliente", $datos["passwordUsuario"], PDO::PARAM_STR);
        

        //ESTA CONTRASEÑA ESTÁ ENCRIPTADA, OJO AL VALIDARLA
        // $stmt->bindParam(":passwordCliente", hash('sha512',$datos["passwordUser"]), PDO::PARAM_STR);
        
        if ($stmt->execute()) {

            return "ok";

        } else {

            return "error";

        }

        $stmt->close();

        $stmt = null;
    }

    static public function mdlRegistrarFactura($datos)
    {
        // update prueba set nombreUsuario=:nombreUsuario where idUsuario=:idUsuario
        // delete from prueba where $item=$valor
        // var_dump("DATOS");
        // var_dump($datos);
        $stmt = Conexion::conectar()->prepare("INSERT INTO factura(almacenFactura ,fechaFactura ,fotoFactura ,idUsuario) VALUES  (:almacenCliente,:fecha ,:foto,:nombreUsuario)");

    

        $stmt->bindParam(":almacenCliente", $datos["almacenFactura"], PDO::PARAM_STR);
        $stmt->bindParam(":fecha", $datos["fechaFactura"], PDO::PARAM_STR);
        $stmt->bindParam(":foto", $datos["rutaImagen"], PDO::PARAM_STR);	
        $stmt->bindParam(":nombreUsuario", $datos["idUsuario"], PDO::PARAM_STR);

        
        if ($stmt->execute()) {

            return "ok";

        } else {

            return "error";

        }

        $stmt->close();

        $stmt = null;
    }

    static public function mdlConsulta($item, $valor)
    {

        if ($item != null) {

            $stmt = Conexion::conectar()->prepare("SELECT * FROM usuario WHERE $item = :$item");

            $stmt->bindParam(":" . $item, $valor, PDO::PARAM_STR);

            $stmt->execute();

            return $stmt->fetchAll();

            $stmt->close();

            $stmt = null;

        } else {

            $stmt = Conexion::conectar()->prepare("SELECT * FROM usuario");
            
            $stmt->execute();

            return $stmt->fetchAll();

        }
    }
    static public function mdlConsultaLogin($usuario, $contraseña)
    {
        
        $stmt = Conexion::conectar()->prepare("SELECT * FROM usuario WHERE emailUsuario='$usuario' and passwordUsuario='$contraseña'");

        $stmt->execute();

        return $stmt->fetch();

        $stmt->close();

        $stmt = null;

    }
    static public function mdlValidarSesion($idUsuario)
    {
        
        $stmt = Conexion::conectar()->prepare("SELECT * FROM usuario WHERE idUsuario='$idUsuario'");

        $stmt->execute();

        return $stmt->fetch();

        $stmt->close();

        $stmt = null;

    }
    static public function mdlActualizarSesion($usuario, $contraseña)
    {
        // update prueba set nombreUsuario=:nombreUsuario where idUsuario=:idUsuario
        // delete from prueba where $item=$valor

        $stmt = Conexion::conectar()->prepare("UPDATE usuario set estadoSesionUsuario=true where emailUsuario='$usuario' and passwordUsuario='$contraseña'");

        if ($stmt->execute()) {

            return "ok";

        } else {

            return "error";

        }

        $stmt->close();

        $stmt = null;
    }
    static public function mdlConsultarCatalogo()
    {

        $stmt = Conexion::conectar()->prepare("SELECT * FROM catalogopremios");

        $stmt->execute();

        return $stmt->fetchAll();

    }
    static public function mdlConsultarActividadesHoy($item, $valor)
    {
        
   
        $stmt = Conexion::conectar()->prepare("SELECT idUsuarioActividad, usuarioactividad.idActividad, idTipoActividad FROM usuarioactividad join actividad on actividad.idActividad= usuarioactividad.idActividad WHERE $item = $valor and fechaActividad=CURRENT_DATE  and idUsuarioActividad not in(select idUsuarioActividad from actividadesfinalizadas)");

        //var_dump("SELECT idUsuarioActividad, usuarioactividad.idActividad, idTipoActividad FROM usuarioactividad join actividad on actividad.idActividad= usuarioActividad.idActividad WHERE $item = $valor and fechaActividad=CURRENT_DATE  and idUsuarioActividad not in(select idUsuarioActividad from actividadesfinalizadas)");
        // $stmt->bindParam(":" . $item, $valor, PDO::PARAM_STR);

        $stmt->execute();

        return $stmt->fetchAll();

        $stmt->close();

        $stmt = null;
    }

    static public function mdlConsultarActividad($tabla, $item, $valor)
    {
        $stmt = Conexion::conectar()->prepare("SELECT * from $tabla WHERE $item = :$item");
        // var_dump("SELECT * from $tabla WHERE $item = $valor");
        $stmt->bindParam(":" . $item, $valor, PDO::PARAM_STR);

        $stmt->execute();

        return $stmt->fetchAll();

        $stmt->close();

        $stmt = null;
    }
    static public function mdlConsultaActividadesDiariasFinalizadas($item, $valor)
    {
   
        $stmt = Conexion::conectar()->prepare("SELECT actividadesfinalizadas.idUsuarioActividad, usuarioactividad.idActividad, actividad.idTipoActividad from actividadesfinalizadas join usuarioactividad on usuarioactividad.idUsuarioActividad=actividadesfinalizadas.idUsuarioActividad join actividad on actividad.idActividad=usuarioactividad.idActividad join tipoactividad on actividad.idTipoActividad=tipoactividad.idTipoActividad where usuarioactividad.idUsuario=$valor and fechaActividad=CURRENT_DATE");

        // $stmt->bindParam(":" . $item, $valor, PDO::PARAM_STR);

        $stmt->execute();

        return $stmt->fetchAll();

        $stmt->close();

        $stmt = null;
    }

    static public function mdlRegistrarActividadFinalizada($datos)
    {
        $stmt = Conexion::conectar()->prepare("INSERT INTO actividadesfinalizadas (idUsuarioActividad ,estado ,puntos) VALUES  (:idUsuarioActividadFinal,:estadoFinal,:puntosFinal)");

        $stmt->bindParam(":idUsuarioActividadFinal", $datos["idUsuarioActividad"], PDO::PARAM_STR);
        $stmt->bindParam(":estadoFinal", $datos["estado"], PDO::PARAM_STR);
        $stmt->bindParam(":puntosFinal", $datos["puntos"], PDO::PARAM_STR);
        
        if ($stmt->execute()) {

            return "ok";

        } else {

            return "error";

        }

        $stmt->close();

        $stmt = null;
    }
    static public function mdlConsultarPuntos($valor)
    {

        $stmt = Conexion::conectar()->prepare("select sum(puntos) as 'puntos' from actividadesfinalizadas join usuarioactividad on usuarioactividad.idUsuarioActividad=actividadesfinalizadas.idUsuarioActividad where usuarioactividad.idUsuario=$valor");

        $stmt->execute();

        return $stmt->fetchAll();

    }

    static public function mdlConsultarRespuestas()
    {

        $stmt = Conexion::conectar()->prepare("SELECT * FROM respuestapregunta");

        $stmt->execute();

        return $stmt->fetchAll();

    }

    static public function mdlInsertarUsuarioPremio($datos)
    {
        $fecha=Date('Y-m-d h:i:s');
        $stmt = Conexion::conectar()->prepare("INSERT INTO premiousuario (fechaReclamoPremio ,idUsuario ,idPremio) VALUES  (:fechaReclamoPremio,:idUsuario,:idPremio)");

        $stmt->bindParam(":fechaReclamoPremio", $fecha, PDO::PARAM_STR);
        $stmt->bindParam(":idUsuario", $datos["idUsuario"], PDO::PARAM_STR);
        $stmt->bindParam(":idPremio", $datos["idPremio"], PDO::PARAM_STR);
        
        if ($stmt->execute()) {

            return "ok";

        } else {

            return "error";

        }

        $stmt->close();

        $stmt = null;
    }

    static public function mdlActualizarPuntosUsuario($datos)
    {
        $fecha=Date('Y-m-d h:i:s');
        $stmt = Conexion::conectar()->prepare("INSERT INTO premiousuario (fechaReclamoPremio ,idUsuario ,idPremio) VALUES  (:fechaReclamoPremio,:idUsuario,:idPremio)");

        $stmt->bindParam(":fechaReclamoPremio", $fecha, PDO::PARAM_STR);
        $stmt->bindParam(":idUsuario", $datos["idUsuario"], PDO::PARAM_STR);
        $stmt->bindParam(":idPremio", $datos["idPremio"], PDO::PARAM_STR);
        
        if ($stmt->execute()) {

            return "ok";

        } else {

            return "error";

        }

        $stmt->close();

        $stmt = null;
    }
    static public function mdlPuntosTotalesUsuario($datos)
    {
      
        $stmt = Conexion::conectar()->prepare("UPDATE puntostotalesusuario set (puntosTotales ,idUsuario ) VALUES  (:puntosTotales,:idUsuario)");

        
        $stmt->bindParam(":idUsuario", $datos["idUsuario"], PDO::PARAM_STR);
        $stmt->bindParam(":puntosTotales", $datos["puntosTotales"], PDO::PARAM_STR);
        
        if ($stmt->execute()) {

            return "ok";

        } else {

            return "error";

        }

        $stmt->close();

        $stmt = null;
    }

    //UPDATE puntostotalesusuario set puntosTotales=$datos["puntosTotales"] where idUsuario=$datos["idUsuario"]
}